extends Node2D
var wave_t: float = 0.0

func _process(delta):
	wave_t += delta * 0.4
	queue_redraw()

func _draw():
	# Deep ocean base - full 2400x1600 map
	draw_rect(Rect2(0, 0, 2400, 1600), Color(0.04, 0.12, 0.22))
	# Ocean wave bands
	for i in range(20):
		var y_base = i * 85.0 + 20
		var wave_offset = sin(wave_t + i * 0.8) * 6.0
		var alpha = 0.06 + i * 0.008
		draw_rect(Rect2(0, y_base + wave_offset, 2400, 42), Color(0.06, 0.18, 0.32, alpha))
	# Scattered sea foam dots
	for i in range(15):
		var x = (i * 173.0) % 2400
		var y = (i * 107.0) % 1600
		var w_off = sin(wave_t * 0.7 + i) * 4.0
		draw_circle(Vector2(x, y + w_off), 3.0, Color(0.15, 0.35, 0.55, 0.3))
	# Horizon fog
	for i in range(3):
		var fog_alpha = 0.08 - i * 0.02
		draw_rect(Rect2(0, i * 30, 2400, 60), Color(0.6, 0.7, 0.8, fog_alpha))
