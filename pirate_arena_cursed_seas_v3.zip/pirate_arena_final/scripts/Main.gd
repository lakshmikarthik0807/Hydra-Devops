extends Node2D

# ─── PIRATE ARENA - MAIN SCENE ────────────────────────────────────────────────
# All nodes are declared directly in Main.tscn.
# This script only handles startup logic that requires runtime (groups, signals).

func _ready():
	GameState.reset()
	# Register runtime groups not set by the scene editor
	var player = $Player
	player.add_to_group("player")
	$Player/Hurtbox.add_to_group("player_hurtbox")
	$SoundManager.add_to_group("sound_manager")
	# Spawn starting weapon after one frame (Player._ready needs to run first)
	_spawn_starting_weapon()

func _spawn_starting_weapon():
	await get_tree().process_frame
	var player = $Player
	var weapon = Node2D.new()
	weapon.set_script(load("res://scripts/WeaponBlunderbuss.gd"))
	player.equip_weapon(weapon)
