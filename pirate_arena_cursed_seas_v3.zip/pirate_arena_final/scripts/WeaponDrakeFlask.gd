extends WeaponBase

# ─── SEA DRAKE FLASK ──────────────────────────────────────────────────────────
# BUFF:  Hurls a flask that explodes into a fire puddle, burning enemies over time
# DEBUFF: Reduces max HP by 25 while equipped (volatile curse)

const HP_REDUCTION = 25.0

func _ready():
	weapon_name = "Sea Drake Flask"
	curse_text = "VOLATILE: Max HP reduced by 25 — liquid fire is unstable!"
	damage = 15.0   # Per tick (DOT)
	attack_cooldown = 2.2
	super._ready()
	_apply_hp_debuff()

func _apply_hp_debuff():
	await get_tree().process_frame
	if owner_player:
		owner_player.max_health -= HP_REDUCTION
		if owner_player.health > owner_player.max_health:
			owner_player.health = owner_player.max_health
		owner_player.emit_signal("health_changed", owner_player.health, owner_player.max_health)

func _notification(what):
	if what == NOTIFICATION_PREDELETE:
		if is_instance_valid(owner_player):
			owner_player.max_health += HP_REDUCTION
			owner_player.emit_signal("health_changed", owner_player.health, owner_player.max_health)

func _do_attack():
	if owner_player == null:
		return
	var target_pos = get_global_mouse_position()
	_throw_flask(target_pos)
	get_tree().call_group("camera", "shake", 5.0, 0.12)
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("cannon_shot")

func _apply_curse():
	pass  # Persistent debuff

func _throw_flask(target: Vector2):
	var flask = Node2D.new()
	flask.add_to_group("player_bullet")
	
	# Visual
	var vis = Node2D.new()
	var vis_script = GDScript.new()
	vis_script.source_code = """
extends Node2D
func _draw():
	draw_circle(Vector2.ZERO, 10, Color(1.0, 0.45, 0.1, 0.9))
	draw_circle(Vector2.ZERO, 6, Color(1.0, 0.8, 0.2, 0.7))
	draw_rect(Rect2(-2, -15, 4, 8), Color(0.6, 0.35, 0.1))
"""
	vis.set_script(vis_script)
	flask.add_child(vis)
	
	flask.global_position = global_position
	var dmg = damage
	
	var script = GDScript.new()
	script.source_code = """
extends Node2D
var start_pos: Vector2
var target_pos: Vector2
var t: float = 0.0
var travel_time: float = 0.55
var exploded: bool = false
var damage_val: float = %f

func setup(sp, tp):
	start_pos = sp
	target_pos = tp

func _process(delta):
	if exploded:
		return
	t += delta / travel_time
	if t >= 1.0:
		t = 1.0
		exploded = true
		_explode()
		return
	# Arc trajectory
	var pos = start_pos.lerp(target_pos, t)
	pos.y -= sin(t * PI) * 90.0
	global_position = pos
	rotation += delta * 6.0

func _explode():
	_spawn_fire_puddle(global_position)
	queue_free()

func _spawn_fire_puddle(pos: Vector2):
	var puddle = Node2D.new()
	puddle.global_position = pos
	var dmg_ref = damage_val
	
	var puddle_script = GDScript.new()
	puddle_script.source_code = \"\"\"
extends Node2D
var lifetime: float = 4.0
var tick_timer: float = 0.0
var tick_interval: float = 0.5
var puddle_radius: float = 60.0
var damage_per_tick: float = %f
var hit_enemies: Array = []

func _process(delta):
	lifetime -= delta
	if lifetime <= 0:
		queue_free()
		return
	tick_timer += delta
	if tick_timer >= tick_interval:
		tick_timer = 0.0
		_burn_enemies()
	queue_redraw()

func _burn_enemies():
	var enemies = get_tree().get_nodes_in_group(\"enemy\")
	for e in enemies:
		if not is_instance_valid(e):
			continue
		if global_position.distance_to(e.global_position) <= puddle_radius:
			if e.has_method(\"take_damage\"):
				e.take_damage(damage_per_tick)

func _draw():
	var alpha = clamp(lifetime / 4.0, 0.2, 0.7)
	draw_circle(Vector2.ZERO, puddle_radius, Color(1.0, 0.35, 0.05, alpha * 0.45))
	draw_arc(Vector2.ZERO, puddle_radius, 0, TAU, 24, Color(1.0, 0.7, 0.1, alpha), 3.0)
	for i in range(6):
		var angle = (i / 6.0) * TAU + lifetime * 2.0
		var r = puddle_radius * 0.5
		draw_circle(Vector2(cos(angle), sin(angle)) * r, 5, Color(1.0, 0.5, 0.0, alpha * 0.6))
\"\"\" % dmg_ref
	puddle.set_script(puddle_script)
	get_tree().current_scene.add_child(puddle)
""" % dmg
	flask.set_script(script)
	flask.call_deferred("setup", global_position, target)
	get_tree().current_scene.add_child(flask)
