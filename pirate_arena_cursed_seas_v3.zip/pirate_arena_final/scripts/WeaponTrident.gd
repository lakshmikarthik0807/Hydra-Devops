extends WeaponBase

# ─── NEPTUNE'S TRIDENT ────────────────────────────────────────────────────────
# BUFF:  Fires 3 piercing water lances simultaneously
# DEBUFF: Slows you by 40% (sea drag curse)

const SLOW_AMOUNT = 0.40  # 40% speed reduction

func _ready():
	weapon_name = "Neptune's Trident"
	curse_text = "SEA DRAG: Movement slowed 40% — the ocean claims its toll!"
	damage = 45.0
	attack_cooldown = 1.0
	knockback_force = 300.0
	super._ready()
	_apply_speed_debuff()

func _apply_speed_debuff():
	await get_tree().process_frame
	if owner_player:
		owner_player.move_speed = owner_player.move_speed * (1.0 - SLOW_AMOUNT)

func _notification(what):
	if what == NOTIFICATION_PREDELETE:
		# Restore speed when weapon is dropped
		if is_instance_valid(owner_player):
			owner_player.move_speed = owner_player.move_speed / (1.0 - SLOW_AMOUNT)

func _do_attack():
	if owner_player == null:
		return
	var shoot_dir = (get_global_mouse_position() - global_position).normalized()
	# Fire 3 prongs: center, +15 deg, -15 deg
	for angle_offset in [-15.0, 0.0, 15.0]:
		var prong_dir = shoot_dir.rotated(deg_to_rad(angle_offset))
		_spawn_lance(prong_dir)
	get_tree().call_group("camera", "shake", 7.0, 0.15)
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("cannon_shot")

func _apply_curse():
	pass  # Curse is persistent (speed debuff applied on equip)

func _spawn_lance(direction: Vector2):
	var b = RigidBody2D.new()
	b.add_to_group("player_bullet")
	b.gravity_scale = 0
	b.linear_damp = 0
	b.collision_layer = 4
	b.collision_mask = 2
	
	var col = CollisionShape2D.new()
	var shape = CapsuleShape2D.new()
	shape.radius = 4.0
	shape.height = 22.0
	col.shape = shape
	col.rotation = direction.angle()
	b.add_child(col)
	
	# Visual: elongated water lance
	var vis = Node2D.new()
	var vis_script = GDScript.new()
	vis_script.source_code = """
extends Node2D
var dir: Vector2 = Vector2.RIGHT
func setup(d): dir = d
func _draw():
	var angle = dir.angle()
	draw_rect(Rect2(-12, -4, 24, 8), Color(0.2, 0.7, 1.0, 0.95))
	draw_rect(Rect2(12, -3, 6, 6), Color(0.8, 0.95, 1.0))
"""
	vis.set_script(vis_script)
	vis.rotation = direction.angle()
	b.add_child(vis)
	
	b.global_position = global_position
	b.linear_velocity = direction * 780.0
	
	var dmg_val = damage
	var script = GDScript.new()
	script.source_code = """
extends RigidBody2D
var lifetime = 0.9
var damage_val = %f
var hit_enemies = []

func _ready():
	body_entered.connect(_on_body)
	contact_monitor = true
	max_contacts_reported = 8

func _process(delta):
	lifetime -= delta
	if lifetime <= 0:
		queue_free()

func _on_body(body):
	if body.is_in_group("enemy") and body not in hit_enemies:
		hit_enemies.append(body)
		if body.has_method("take_damage"):
			body.take_damage(damage_val)
		# Piercing: do NOT free, continue through enemies
""" % dmg_val
	b.set_script(script)
	get_tree().current_scene.add_child(b)
