extends Node2D

func _draw():
	draw_rect(Rect2(40, 44, 2320, 1512), Color(0.22, 0.14, 0.07))
	var plank_color = Color(0.18, 0.11, 0.05)
	var highlight = Color(0.28, 0.18, 0.09, 0.5)
	for y in range(44, 1556, 28):
		draw_line(Vector2(40, y), Vector2(2360, y), plank_color, 2.0)
		draw_line(Vector2(40, y + 1), Vector2(2360, y + 1), highlight, 1.0)
	for x in range(40, 2360, 80):
		draw_line(Vector2(x, 44), Vector2(x, 1556), Color(0.15, 0.09, 0.04, 0.7), 1.5)
	draw_line(Vector2(1200, 44), Vector2(1200, 1556), Color(0.35, 0.22, 0.1, 0.3), 3.0)
	draw_line(Vector2(40, 800), Vector2(2360, 800), Color(0.35, 0.22, 0.1, 0.3), 3.0)
	draw_arc(Vector2(1200, 800), 120, 0, TAU, 48, Color(0.35, 0.22, 0.1, 0.22), 2.0)
	draw_arc(Vector2(1200, 800), 60, 0, TAU, 24, Color(0.35, 0.22, 0.1, 0.2), 1.5)
	for angle in [0, PI/2, PI, 3*PI/2]:
		var d = Vector2(cos(angle), sin(angle))
		draw_line(Vector2(1200, 800) + d * 60, Vector2(1200, 800) + d * 120, Color(0.4, 0.25, 0.1, 0.3), 2.0)
	for qpos in [Vector2(600, 400), Vector2(1800, 400), Vector2(600, 1200), Vector2(1800, 1200)]:
		draw_arc(qpos, 50, 0, TAU, 24, Color(0.35, 0.22, 0.1, 0.15), 1.5)
		for angle in [0, PI/2, PI, 3*PI/2]:
			var d = Vector2(cos(angle), sin(angle))
			draw_line(qpos + d * 25, qpos + d * 50, Color(0.4, 0.25, 0.1, 0.2), 1.5)
