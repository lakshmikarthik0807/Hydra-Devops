extends CanvasLayer

# ─── PIRATE HUD ───────────────────────────────────────────────────────────────
@onready var health_fill: ColorRect = $HUDPanel/HealthBar/Fill
@onready var health_label: Label = $HUDPanel/HealthBar/Label
@onready var score_label: Label = $HUDPanel/ScoreLabel
@onready var wave_label: Label = $HUDPanel/WaveLabel
@onready var weapon_label: Label = $HUDPanel/WeaponLabel
@onready var curse_label: Label = $HUDPanel/CurseLabel
@onready var timer_label: Label = $HUDPanel/TimerLabel
@onready var wave_announce: Label = $WaveAnnounce
@onready var game_over_panel: Panel = $GameOverPanel
@onready var next_wave_label: Label = $CountdownPanel/NextWaveLabel
@onready var enemies_label: Label = $EnemiesLabel

var announce_timer: float = 0.0
const ANNOUNCE_DURATION: float = 2.5

func _ready():
	await get_tree().process_frame
	var players = get_tree().get_nodes_in_group("player")
	if players.size() > 0:
		var player = players[0]
		player.health_changed.connect(_on_health_changed)
		player.player_died.connect(_on_player_died)
		player.weapon_changed.connect(_on_weapon_changed)
	
	GameState.wave_started.connect(_on_wave_started)
	
	wave_label.text = "⚓ Wave: 1"
	score_label.text = "Kills: 0  |  Score: 0"
	weapon_label.text = "⚔ Fists"
	curse_label.text = ""
	wave_announce.modulate.a = 0.0
	game_over_panel.visible = false

func _process(delta):
	if announce_timer > 0:
		announce_timer -= delta
		wave_announce.modulate.a = min(1.0, announce_timer) if announce_timer > 0.5 else announce_timer * 2
	
	score_label.text = "Kills: %d  |  Score: %d" % [GameState.enemies_killed, GameState.score]
	var mins = int(GameState.survival_time) / 60
	var secs = int(GameState.survival_time) % 60
	timer_label.text = "⏱ Time: %02d:%02d" % [mins, secs]
	wave_label.text = "⚓ Wave: %d" % GameState.current_wave
	
	# Update enemies alive count
	var enemies = get_tree().get_nodes_in_group("enemy")
	var alive_count = 0
	for e in enemies:
		if is_instance_valid(e) and not e.is_dead:
			alive_count += 1
	if enemies_label:
		enemies_label.text = "Enemies: %d" % alive_count

func _on_health_changed(new_health: float, max_health: float):
	var pct = clamp(new_health / max_health, 0.0, 1.0)
	health_fill.size.x = 160.0 * pct
	health_fill.color = Color(0.9, 0.1, 0.1).lerp(Color(0.1, 0.85, 0.1), pct)
	health_label.text = "%d / %d" % [int(new_health), int(max_health)]

func _on_player_died():
	game_over_panel.visible = true
	var score_final = $GameOverPanel/FinalScore
	var time_final = $GameOverPanel/FinalTime
	var wave_final = $GameOverPanel/FinalWave
	if score_final:
		score_final.text = "Score: %d  |  Kills: %d" % [GameState.score, GameState.enemies_killed]
	if time_final:
		var mins = int(GameState.survival_time) / 60
		var secs = int(GameState.survival_time) % 60
		time_final.text = "Survived: %02d:%02d" % [mins, secs]
	if wave_final:
		wave_final.text = "Reached Wave: %d" % GameState.current_wave

func _on_weapon_changed(weapon_name: String, curse_text: String):
	weapon_label.text = "⚔ " + weapon_name
	# Show debuff in red with pulsing
	curse_label.text = "⚠ CURSE: " + curse_text
	curse_label.add_theme_color_override("font_color", Color(1.0, 0.25, 0.25))
	var tween = create_tween()
	tween.set_loops(3)
	tween.tween_property(curse_label, "modulate", Color(1.5, 0.5, 0.5), 0.2)
	tween.tween_property(curse_label, "modulate", Color(1.0, 1.0, 1.0), 0.2)

func _on_wave_started(wave_num: int):
	wave_announce.text = "⚓  WAVE %d  ⚓" % wave_num
	announce_timer = ANNOUNCE_DURATION
	if next_wave_label:
		next_wave_label.text = "⚓ Next Wave: -"
	var tween = create_tween()
	tween.tween_property(wave_announce, "scale", Vector2(1.3, 1.3), 0.15)
	tween.tween_property(wave_announce, "scale", Vector2(1.0, 1.0), 0.15)

func _input(event):
	if GameState.is_game_over:
		if event is InputEventKey and event.pressed and event.keycode == KEY_R:
			get_tree().reload_current_scene()
