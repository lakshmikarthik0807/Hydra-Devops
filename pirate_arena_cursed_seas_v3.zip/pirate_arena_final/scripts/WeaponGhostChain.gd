extends WeaponBase

# ─── GHOST CHAIN ──────────────────────────────────────────────────────────────
# BUFF:  Rapid whip that chains to 3 nearby enemies per swing
# DEBUFF: Each swing has 25% chance to briefly stun YOU (ghost possession)

func _ready():
	weapon_name = "Ghost Chain"
	curse_text = "POSSESSION: 25% chance each swing freezes you for 0.6s!"
	damage = 32.0
	attack_cooldown = 0.45
	knockback_force = 280.0
	super._ready()

func _do_attack():
	var primary_pos = global_position
	var enemies = get_tree().get_nodes_in_group("enemy")
	
	# Sort by distance, pick 3 closest
	enemies.sort_custom(func(a, b): 
		return a.global_position.distance_to(primary_pos) < b.global_position.distance_to(primary_pos))
	
	var max_chain = min(3, enemies.size())
	var chain_range = 220.0
	var hit_count = 0
	
	for i in range(enemies.size()):
		if hit_count >= max_chain:
			break
		var e = enemies[i]
		if not is_instance_valid(e):
			continue
		var dist = e.global_position.distance_to(primary_pos)
		if dist <= chain_range:
			if e.has_method("take_damage"):
				var knock_dir = (e.global_position - primary_pos).normalized()
				e.take_damage(damage, knock_dir, knockback_force)
			_spawn_chain_visual(primary_pos, e.global_position)
			hit_count += 1
	
	get_tree().call_group("camera", "shake", 5.0, 0.1)
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("sword_slash")

func _apply_curse():
	if owner_player == null:
		return
	if randf() < 0.25:
		# Stun the player briefly
		owner_player.set_meta("stunned", true)
		var prev_speed = owner_player.move_speed
		owner_player.move_speed = 0.0
		var timer = get_tree().create_timer(0.6)
		timer.timeout.connect(func():
			if is_instance_valid(owner_player):
				owner_player.move_speed = prev_speed
				owner_player.remove_meta("stunned")
		)
		# Visual feedback: ghost flicker
		if owner_player.has_node("Sprite2D"):
			owner_player.get_node("Sprite2D").modulate = Color(0.5, 1.0, 0.5, 0.4)
			var restore = get_tree().create_timer(0.6)
			restore.timeout.connect(func():
				if is_instance_valid(owner_player) and owner_player.has_node("Sprite2D"):
					owner_player.get_node("Sprite2D").modulate = Color(1, 1, 1, 1)
			)

func _spawn_chain_visual(from: Vector2, to: Vector2):
	var chain = Node2D.new()
	var script = GDScript.new()
	var fx = from.x; var fy = from.y
	var tx = to.x;   var ty = to.y
	script.source_code = """
extends Node2D
var lifetime: float = 0.18
var from_pos: Vector2 = Vector2(%f, %f)
var to_pos: Vector2 = Vector2(%f, %f)

func _process(delta):
	lifetime -= delta
	if lifetime <= 0:
		queue_free()
		return
	queue_redraw()

func _draw():
	var alpha = lifetime / 0.18
	draw_line(from_pos, to_pos, Color(0.4, 1.0, 0.6, alpha * 0.9), 3.0)
	draw_circle(to_pos, 6.0, Color(0.6, 1.0, 0.7, alpha * 0.7))
	# Chain links
	var segments = 5
	for i in range(segments):
		var t = float(i) / segments
		var p = from_pos.lerp(to_pos, t)
		draw_circle(p, 3.0, Color(0.2, 0.9, 0.5, alpha * 0.5))
""" % [fx, fy, tx, ty]
	chain.set_script(script)
	get_tree().current_scene.add_child(chain)
