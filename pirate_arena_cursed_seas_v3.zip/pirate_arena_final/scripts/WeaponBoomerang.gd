extends WeaponBase

# ─── CURSED BOOMERANG ─────────────────────────────────────────────────────────
var active_boomerang: Node2D = null

func _ready():
	weapon_name = "Cursed Boomerang"
	curse_text = "RETURNS: The boomerang comes back — dodge it yourself!"
	damage = 40.0
	attack_cooldown = 2.0
	super._ready()

func _do_attack():
	if active_boomerang != null and is_instance_valid(active_boomerang):
		return
	
	var throw_dir = (get_global_mouse_position() - global_position).normalized()
	active_boomerang = _create_boomerang(throw_dir)
	get_tree().current_scene.add_child(active_boomerang)
	get_tree().call_group("camera", "shake", 3.0, 0.1)

func _apply_curse():
	pass

func _create_boomerang(direction: Vector2) -> Node2D:
	var b = Node2D.new()
	b.add_to_group("player_bullet")
	
	var vis = ColorRect.new()
	vis.size = Vector2(18, 18)
	vis.position = Vector2(-9, -9)
	vis.color = Color(0.3, 0.9, 1.0)
	b.add_child(vis)
	
	var area = Area2D.new()
	var col = CollisionShape2D.new()
	var shape = CircleShape2D.new()
	shape.radius = 12.0
	col.shape = shape
	area.add_child(col)
	area.collision_layer = 4
	area.collision_mask = 2 | 8
	b.add_child(area)
	
	b.global_position = global_position
	
	var dmg = damage
	var owner_ref = owner_player
	var throw_target = global_position + direction * 350.0
	
	var script = GDScript.new()
	script.source_code = """
extends Node2D
var start_pos: Vector2
var peak_pos: Vector2
var owner_player
var throw_target: Vector2
var damage_val: float = %f
var t: float = 0.0
var returning: bool = false
var hit_enemies: Array = []
var hit_player: bool = false

func setup(sp, tp, player_node):
	start_pos = sp
	throw_target = tp
	owner_player = player_node
	var mid = (sp + tp) / 2.0
	var perp = (tp - sp).rotated(PI / 2.0).normalized() * 80.0
	peak_pos = mid + perp

func _ready():
	var area = get_child(1)
	area.area_entered.connect(_on_area)
	area.body_entered.connect(_on_body)

func _process(delta):
	t += delta * 1.2
	if not returning:
		if t >= 1.0:
			returning = true
			t = 0.0
	
	if not returning:
		var pos = start_pos.lerp(peak_pos, t).lerp(peak_pos.lerp(throw_target, t), t)
		global_position = pos
		rotation += delta * 8.0
	else:
		if is_instance_valid(owner_player):
			var target = owner_player.global_position
			global_position = global_position.lerp(target, t * 1.5 * delta * 3.0)
			rotation -= delta * 12.0
			if global_position.distance_to(target) < 20.0:
				queue_free()
		else:
			queue_free()

func _on_body(body):
	if body.is_in_group("enemy") and body not in hit_enemies:
		hit_enemies.append(body)
		if body.has_method("take_damage"):
			body.take_damage(damage_val)

func _on_area(area):
	if area.is_in_group("player_hurtbox") and returning and not hit_player:
		hit_player = true
		var player = area.get_parent()
		if player.has_method("take_damage"):
			player.take_damage(15.0, Vector2.ZERO, 100.0)
""" % dmg
	
	b.set_script(script)
	b.call_deferred("setup", global_position, throw_target, owner_ref)
	return b
