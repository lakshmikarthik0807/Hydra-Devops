extends WeaponBase

# ─── CONFUSION WAND ───────────────────────────────────────────────────────────
const EXPLOSION_RADIUS = 160.0
const CONTROL_REVERSE_DURATION = 3.0

func _ready():
	weapon_name = "Confusion Wand"
	curse_text = "DISORIENTED: Controls REVERSE for 3 seconds after firing!"
	damage = 55.0
	attack_cooldown = 3.5
	super._ready()

func _do_attack():
	var enemies_hit = hit_enemies_in_range(EXPLOSION_RADIUS, 360.0)
	for enemy in enemies_hit:
		if enemy.has_method("take_damage"):
			var dist = global_position.distance_to(enemy.global_position)
			var falloff = 1.0 - (dist / EXPLOSION_RADIUS) * 0.4
			enemy.take_damage(damage * falloff)
			var knock_dir = (enemy.global_position - global_position).normalized()
			if enemy.has_method("apply_knockback"):
				enemy.apply_knockback(knock_dir * 350.0)
	
	_spawn_explosion_visual()
	get_tree().call_group("camera", "shake", 18.0, 0.35)

func _apply_curse():
	if owner_player == null:
		return
	owner_player.move_speed = -abs(owner_player.move_speed)
	var timer = get_tree().create_timer(CONTROL_REVERSE_DURATION)
	timer.timeout.connect(func(): 
		if is_instance_valid(owner_player):
			owner_player.move_speed = abs(owner_player.move_speed)
	)

func _spawn_explosion_visual():
	var exp_node = Node2D.new()
	var exp_script = GDScript.new()
	exp_script.source_code = """
extends Node2D
var timer: float = 0.45
var radius: float = %f

func _process(delta):
	timer -= delta
	if timer <= 0:
		queue_free()
		return
	queue_redraw()

func _draw():
	var alpha = timer / 0.45
	var current_r = radius * (1.0 - alpha * 0.3)
	draw_circle(Vector2.ZERO, current_r, Color(0.6, 0.2, 1.0, alpha * 0.4))
	draw_arc(Vector2.ZERO, current_r, 0, TAU, 32, Color(1.0, 0.5, 1.0, alpha), 3.0)
""" % EXPLOSION_RADIUS
	exp_node.set_script(exp_script)
	exp_node.global_position = global_position
	get_tree().current_scene.add_child(exp_node)
