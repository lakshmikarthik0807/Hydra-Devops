# ⚔ CURSED ARENA ⚔
### A Chaotic Top-Down Survival Game — Godot 4.x

> *"Trapped in a single combat arena, armed with cursed weapons, facing endless escalating swarms. There is no escape. Only survival."*

---

## 🕹 HOW TO RUN

1. **Install Godot 4.3+** from [godotengine.org](https://godotengine.org)
2. Open Godot → **Import Project** → select the `cursed_arena/` folder
3. Press **F5** or the ▶ Play button
4. The game starts immediately — no menus, just chaos.

**Controls:**
| Key | Action |
|-----|--------|
| `W A S D` | Move |
| `LMB` (Left Click) | Attack |
| `E` | Pick Up / Swap weapon |
| `R` | Restart (when dead) |

---

## 🏗 PROJECT ARCHITECTURE

```
cursed_arena/
├── project.godot          ← Godot config, input map, autoloads
├── icon.svg               ← App icon
├── scenes/
│   └── Main.tscn          ← Root scene (script-built, no node tree bloat)
└── scripts/
    ├── GameState.gd        ← Autoload singleton: score, wave, time
    ├── Main.gd             ← Scene builder: arena, player, HUD, camera
    ├── Player.gd           ← CharacterBody2D: movement, health, weapon slot
    ├── WeaponBase.gd       ← Abstract weapon with helper methods
    ├── WeaponBlunderbuss.gd ← Shotgun pellets + self-knockback curse
    ├── WeaponSword.gd      ← Fast arc swing + HP drain curse
    ├── WeaponBoomerang.gd  ← Returning projectile + self-hit risk curse
    ├── WeaponWand.gd       ← AoE explosion + control-reverse curse
    ├── EnemyBase.gd        ← CharacterBody2D: seek AI, wave scaling
    ├── EnemySpeeder.gd     ← Zigzag fast enemy
    ├── EnemyTank.gd        ← State-machine charge enemy
    ├── WaveManager.gd      ← Wave composition, spawn scheduling
    ├── CameraShake.gd      ← Exponential-decay screen shake
    └── HUD.gd              ← CanvasLayer UI: health, score, wave, curse
```

---

## ⚙ ENGINEERING DESIGN

### 1. Scene Construction via Code (Main.gd)
Rather than using `.tscn` XML files for every node, the entire scene is **built programmatically** in `Main.gd`. This means:
- No brittle scene file references that break on rename
- Every node is traceable in version control as pure GDScript
- Easy to iterate on layout without opening the Godot editor

```
Main._ready()
  ├── _build_arena()     → StaticBody2D walls + visual ColorRects
  ├── _build_player()    → CharacterBody2D + sub-nodes
  ├── _build_wave_manager()
  ├── _build_camera()    → Camera2D + shake script
  ├── _build_hud()       → CanvasLayer + all UI nodes
  └── _spawn_starting_weapon()
```

### 2. The Cursed Arsenal — One-Slot Weapon System
```
Player
  └── WeaponHolder (Node2D, rotates toward mouse)
        └── [ONE weapon node at a time]

equip_weapon(new_weapon):
  if current_weapon != null:
    drop it into the scene as a pickup
  add new_weapon to WeaponHolder
  emit weapon_changed signal → HUD updates
```

**Curse Implementation Pattern:**
Every weapon overrides two methods:
- `_do_attack()` — the actual hit/projectile logic
- `_apply_curse()` — the chaotic drawback applied on the same frame

| Weapon | Attack | Curse |
|--------|--------|-------|
| **Blunderbuss** | 7-pellet shotgun spread | Self-knockback force = 600 |
| **Vampiric Sword** | Fast arc (120°, 0.28s CD) | -3 HP per swing |
| **Cursed Boomerang** | Bezier-arc projectile | Returns and can hit player |
| **Confusion Wand** | AoE explosion (r=160px) | Controls reverse 3 seconds |

### 3. Escalating Wave System — Composition Table

```
Wave N:
  grunts   = 4 + N*2
  speeders = max(0, N-1) * 2
  tanks    = max(0, N-3)
  
  Every 5 waves (SURGE):
    grunts   += 8
    speeders += 4
    tanks    += 2

Enemy stat scaling:
  health = base_health * (1 + (wave-1) * 0.18)
  speed  = base_speed  * (1 + (wave-1) * 0.12)
  damage = base_damage * (1 + (wave-1) * 0.10)
```

Enemies are spawned from a shuffled queue with a timer interval that **decreases each wave** (min 0.15s), creating increasing density pressure.

### 4. Screen Shake — Exponential Decay Model

```gdscript
# CameraShake.gd
current_intensity = A0 * (1 - t/T)²   # quadratic decay
offset = Vector2(rand(-I, I), rand(-I, I))
```

Every impact calls `get_tree().call_group("camera", "shake", intensity, duration)`, allowing any script to trigger shake without a direct reference.

### 5. GameState Singleton (Autoload)

```
GameState (Node, autoloaded)
  ├── score: int
  ├── enemies_killed: int
  ├── current_wave: int
  ├── survival_time: float
  └── signals: wave_started, score_changed, game_over_signal
```

All subsystems read/write through `GameState` — no tight coupling between HUD ↔ WaveManager ↔ Player.

---

## 🎮 GAME FEEL CHECKLIST
- [x] Screen shake on every hit, death, explosion
- [x] Enemy death tween (shrink + fade)
- [x] Weapon curse text flashes red in HUD
- [x] Wave announcement animates scale pulse
- [x] Health bar color-shifts green → red
- [x] Enemy flash white on damage
- [x] Player flashes orange-red on damage
- [x] Invincibility frames (0.3s) after player hit
- [x] Controls-reversed tints player purple (Wand curse)

---

## 🔧 EXTENDING THE GAME

**Add a new weapon:**
1. Create `scripts/WeaponMyWeapon.gd` extending `WeaponBase`
2. Override `_ready()` (set stats), `_do_attack()`, `_apply_curse()`
3. Add it to the `weapons` array in `WaveManager._spawn_weapon_pickup()`

**Add a new enemy type:**
1. Create `scripts/EnemyMyType.gd` extending `EnemyBase`
2. Override `get_enemy_color()` and `_move_toward_player()`
3. Add `"mytype"` to `_build_wave_queue()` in `WaveManager.gd`

---

## 📋 JUDGING REQUIREMENTS MET

| Requirement | Implementation |
|-------------|---------------|
| Single closed arena | `_build_arena()` — 4 StaticBody2D walls, no exits |
| Enemies spawn in waves | `WaveManager` — shuffled queue, per-wave composition |
| Every wave gets harder | Stat scaling formula + surge waves every 5 |
| One weapon at a time | `Player.equip_weapon()` — drops old, equips new |
| Every weapon has a curse | `_apply_curse()` in each weapon script |
| No complex inventory menu | Pickup = walk over or press E. That's it. |
| Health visible in UI | Health bar + numeric label, color-coded |
| Score visible in UI | Kills + Score + Survival time, always on screen |

---

*Built for the Cursed Arsenal Game Jam — "Dumb Fun" track*
