extends Node2D

var lifetime: float = 0.18
var from_pos: Vector2 = Vector2.ZERO
var to_pos: Vector2 = Vector2.ZERO

func _process(delta):
	lifetime -= delta
	if lifetime <= 0:
		queue_free()
		return
	queue_redraw()

func _draw():
	var alpha = lifetime / 0.18
	draw_line(from_pos, to_pos, Color(0.4, 1.0, 0.6, alpha * 0.9), 3.0)
	draw_circle(to_pos, 6.0, Color(0.6, 1.0, 0.7, alpha * 0.7))
	var segments = 5
	for i in range(segments):
		var t = float(i) / segments
		var p = from_pos.lerp(to_pos, t)
		draw_circle(p, 3.0, Color(0.2, 0.9, 0.5, alpha * 0.5))
