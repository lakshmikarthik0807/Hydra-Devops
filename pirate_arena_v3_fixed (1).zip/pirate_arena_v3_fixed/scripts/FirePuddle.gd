extends Node2D

var lifetime: float = 4.0
var tick_timer: float = 0.0
var tick_interval: float = 0.5
var puddle_radius: float = 60.0
var damage_per_tick: float = 15.0

func _process(delta):
	lifetime -= delta
	if lifetime <= 0:
		queue_free()
		return
	tick_timer += delta
	if tick_timer >= tick_interval:
		tick_timer = 0.0
		_burn_enemies()
	queue_redraw()

func _burn_enemies():
	var enemies = get_tree().get_nodes_in_group("enemy")
	for e in enemies:
		if not is_instance_valid(e):
			continue
		if global_position.distance_to(e.global_position) <= puddle_radius:
			if e.has_method("take_damage"):
				e.take_damage(damage_per_tick)

func _draw():
	var alpha = clamp(lifetime / 4.0, 0.2, 0.7)
	draw_circle(Vector2.ZERO, puddle_radius, Color(1.0, 0.35, 0.05, alpha * 0.45))
	draw_arc(Vector2.ZERO, puddle_radius, 0, TAU, 24, Color(1.0, 0.7, 0.1, alpha), 3.0)
	for i in range(6):
		var angle = (i / 6.0) * TAU + lifetime * 2.0
		var r = puddle_radius * 0.5
		draw_circle(Vector2(cos(angle), sin(angle)) * r, 5, Color(1.0, 0.5, 0.0, alpha * 0.6))
