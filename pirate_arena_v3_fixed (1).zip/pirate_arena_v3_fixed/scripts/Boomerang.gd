extends Node2D

var start_pos: Vector2
var peak_pos: Vector2
var owner_player: Node
var throw_target: Vector2
var damage_val: float = 40.0
var t: float = 0.0
var returning: bool = false
var hit_enemies: Array = []
var hit_player: bool = false

func setup(sp: Vector2, tp: Vector2, player_node: Node):
	start_pos = sp
	throw_target = tp
	owner_player = player_node
	var mid = (sp + tp) / 2.0
	var perp = (tp - sp).rotated(PI / 2.0).normalized() * 80.0
	peak_pos = mid + perp

func _ready():
	var area = get_child(1)
	area.area_entered.connect(_on_area)
	area.body_entered.connect(_on_body)

func _process(delta):
	t += delta * 1.2
	if not returning:
		if t >= 1.0:
			returning = true
			t = 0.0

	if not returning:
		var pos = start_pos.lerp(peak_pos, t).lerp(peak_pos.lerp(throw_target, t), t)
		global_position = pos
		rotation += delta * 8.0
	else:
		if is_instance_valid(owner_player):
			var target = owner_player.global_position
			global_position = global_position.lerp(target, t * 1.5 * delta * 3.0)
			rotation -= delta * 12.0
			if global_position.distance_to(target) < 20.0:
				queue_free()
		else:
			queue_free()

func _on_body(body):
	if body.is_in_group("enemy") and body not in hit_enemies:
		hit_enemies.append(body)
		if body.has_method("take_damage"):
			body.take_damage(damage_val)

func _on_area(area):
	if area.is_in_group("player_hurtbox") and returning and not hit_player:
		hit_player = true
		var player = area.get_parent()
		if player.has_method("take_damage"):
			player.take_damage(15.0, Vector2.ZERO, 100.0)
