extends Node2D

var _t: float = 0.0

func _process(d):
	_t += d * 0.4
	queue_redraw()

func _draw():
	draw_rect(Rect2(0, 0, 2400, 1600), Color(0.04, 0.12, 0.22))
	for i in 20:
		var y = i * 85.0 + 20 + sin(_t + i * 0.8) * 6.0
		draw_rect(Rect2(0, y, 2400, 42), Color(0.06, 0.18, 0.32, 0.06 + i * 0.008))
	for i in 15:
		draw_circle(Vector2(fmod(i * 173.0, 2400), fmod(i * 107.0, 1600) + sin(_t * 0.7 + i) * 4.0), 3.0, Color(0.15, 0.35, 0.55, 0.3))
	for i in 3:
		draw_rect(Rect2(0, i * 30, 2400, 60), Color(0.6, 0.7, 0.8, 0.08 - i * 0.02))
