extends Node

# ─── GLOBAL GAME STATE ───────────────────────────────────────────────────────
var score: int = 0
var enemies_killed: int = 0
var current_wave: int = 0
var is_game_over: bool = false
var survival_time: float = 0.0

# Signals
signal wave_started(wave_num: int)
signal score_changed(new_score: int)
signal game_over_signal()

func _ready():
	reset()

func reset():
	score = 0
	enemies_killed = 0
	current_wave = 0
	is_game_over = false
	survival_time = 0.0

func add_score(amount: int):
	score += amount
	emit_signal("score_changed", score)

func kill_enemy():
	enemies_killed += 1
	add_score(10 + current_wave * 2)

func _process(delta):
	if not is_game_over:
		survival_time += delta
