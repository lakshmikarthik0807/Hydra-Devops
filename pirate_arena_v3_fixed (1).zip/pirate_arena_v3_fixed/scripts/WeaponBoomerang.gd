extends WeaponBase

# ─── CURSED BOOMERANG ─────────────────────────────────────────────────────────
var active_boomerang: Node2D = null

func _ready():
	weapon_name = "Cursed Boomerang"
	curse_text = "RETURNS: The boomerang comes back — dodge it yourself!"
	damage = 40.0
	attack_cooldown = 2.0
	super._ready()

func _do_attack():
	if active_boomerang != null and is_instance_valid(active_boomerang):
		return
	
	var throw_dir = (get_global_mouse_position() - global_position).normalized()
	active_boomerang = _create_boomerang(throw_dir)
	get_tree().current_scene.add_child(active_boomerang)
	get_tree().call_group("camera", "shake", 3.0, 0.1)

func _apply_curse():
	pass

func _create_boomerang(direction: Vector2) -> Node2D:
	var b = load("res://scripts/Boomerang.gd").new()
	b.add_to_group("player_bullet")
	b.damage_val = damage
	
	var vis = ColorRect.new()
	vis.size = Vector2(18, 18)
	vis.position = Vector2(-9, -9)
	vis.color = Color(0.3, 0.9, 1.0)
	vis.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(vis)
	
	var area = Area2D.new()
	var col = CollisionShape2D.new()
	var shape = CircleShape2D.new()
	shape.radius = 12.0
	col.shape = shape
	area.add_child(col)
	area.collision_layer = 4
	area.collision_mask = 2 | 8
	b.add_child(area)
	
	b.global_position = global_position
	b.call_deferred("setup", global_position, global_position + direction * 350.0, owner_player)
	return b
