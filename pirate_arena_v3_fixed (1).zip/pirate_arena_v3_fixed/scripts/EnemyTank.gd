extends EnemyBase

# ─── TANK PIRATE ──────────────────────────────────────────────────────────────
enum State { WALK, TELEGRAPH, CHARGE, COOLDOWN }
var state: State = State.WALK

var charge_dir: Vector2 = Vector2.ZERO
var telegraph_timer: float = 0.0
var charge_timer: float = 0.0
var cooldown_timer: float = 0.0

const TELEGRAPH_DURATION: float = 0.8
const CHARGE_DURATION: float = 0.35
const CHARGE_SPEED: float = 500.0
const CHARGE_RANGE: float = 220.0
const COOLDOWN_DURATION: float = 1.2

func _ready():
	base_health = 90.0
	base_speed = 55.0
	base_damage = 25.0
	score_value = 35
	super._ready()
	# Scale up
	if sprite:
		sprite.scale = Vector2(0.7, 0.7)

func _get_enemy_texture() -> Texture2D:
	var tex_path = "res://assets/textures/enemy_tank.png"
	if ResourceLoader.exists(tex_path):
		return load(tex_path)
	return null

func _move_toward_player(delta):
	if player == null or not is_instance_valid(player):
		return
	
	match state:
		State.WALK:
			var dist = global_position.distance_to(player.global_position)
			if dist < CHARGE_RANGE:
				state = State.TELEGRAPH
				telegraph_timer = TELEGRAPH_DURATION
				velocity = Vector2.ZERO
			else:
				var dir = (player.global_position - global_position).normalized()
				velocity = dir * speed
		
		State.TELEGRAPH:
			telegraph_timer -= delta
			if sprite:
				sprite.modulate = Color(2.0, 1.0, 0.2) if fmod(telegraph_timer * 6, 2) > 1 else Color(1.0, 1.0, 1.0)
			velocity = Vector2.ZERO
			if telegraph_timer <= 0:
				charge_dir = (player.global_position - global_position).normalized()
				state = State.CHARGE
				charge_timer = CHARGE_DURATION
				get_tree().call_group("camera", "shake", 5.0, 0.1)
		
		State.CHARGE:
			charge_timer -= delta
			velocity = charge_dir * CHARGE_SPEED
			if charge_timer <= 0:
				state = State.COOLDOWN
				cooldown_timer = COOLDOWN_DURATION
		
		State.COOLDOWN:
			cooldown_timer -= delta
			velocity = Vector2.ZERO
			if sprite:
				sprite.modulate = Color(0.7, 0.7, 0.7)
			if cooldown_timer <= 0:
				if sprite:
					sprite.modulate = Color(1.0, 1.0, 1.0)
				state = State.WALK
