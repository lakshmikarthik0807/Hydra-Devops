extends Node

# ─── PIRATE WAVE MANAGER ──────────────────────────────────────────────────────
const ARENA_CENTER = Vector2(1200, 800)
const SPAWN_MARGIN = 50.0
const ARENA_HALF_W = 1140.0
const ARENA_HALF_H = 740.0

var current_wave: int = 0
var enemies_alive: int = 0
var wave_in_progress: bool = false
var between_wave_timer: float = 0.0
const BETWEEN_WAVE_DELAY: float = 4.0

var spawn_queue: Array = []
var spawn_interval: float = 0.0
var spawn_timer_accum: float = 0.0

signal wave_complete(wave_num: int)
signal next_wave_countdown(seconds_left: float)

func _ready():
	var t = get_tree().create_timer(1.5)
	t.timeout.connect(start_next_wave)

func _process(delta):
	if GameState.is_game_over:
		return
	
	if not wave_in_progress and between_wave_timer > 0:
		between_wave_timer -= delta
		emit_signal("next_wave_countdown", between_wave_timer)
		if between_wave_timer <= 0:
			start_next_wave()
	
	if wave_in_progress and spawn_queue.size() > 0:
		spawn_timer_accum += delta
		if spawn_timer_accum >= spawn_interval:
			spawn_timer_accum = 0.0
			_spawn_next_from_queue()

func start_next_wave():
	if GameState.is_game_over:
		return
	current_wave += 1
	GameState.current_wave = current_wave
	wave_in_progress = true
	enemies_alive = 0
	spawn_queue = _build_wave_queue(current_wave)
	spawn_interval = max(0.12, 0.5 - current_wave * 0.03)
	spawn_timer_accum = 0.0
	GameState.emit_signal("wave_started", current_wave)
	
	# Play wave fanfare
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("wave_fanfare", -6.0)

func _build_wave_queue(wave: int) -> Array:
	var queue = []
	var base_grunts = 4 + wave * 2
	var base_speeders = max(0, wave - 1) * 2
	var base_tanks = max(0, wave - 3)
	
	# Surge wave every 5
	if wave % 5 == 0:
		base_grunts += 10
		base_speeders += 5
		base_tanks += 3
	
	for i in range(base_grunts):
		queue.append("grunt")
	for i in range(base_speeders):
		queue.append("speeder")
	for i in range(base_tanks):
		queue.append("tank")
	
	queue.shuffle()
	return queue

func _spawn_next_from_queue():
	if spawn_queue.size() == 0:
		return
	var type = spawn_queue.pop_front()
	_spawn_enemy(type)

func _spawn_enemy(type: String):
	var enemy: CharacterBody2D = null
	
	match type:
		"grunt":
			enemy = CharacterBody2D.new()
			enemy.set_script(load("res://scripts/EnemyBase.gd"))
		"speeder":
			enemy = CharacterBody2D.new()
			enemy.set_script(load("res://scripts/EnemySpeeder.gd"))
		"tank":
			enemy = CharacterBody2D.new()
			enemy.set_script(load("res://scripts/EnemyTank.gd"))
	
	if enemy == null:
		return
	
	enemy.wave_number = current_wave
	enemy.global_position = _get_spawn_position()
	enemy.enemy_died.connect(_on_enemy_died)
	get_tree().current_scene.add_child(enemy)
	enemies_alive += 1

func _get_spawn_position() -> Vector2:
	var edge = randi() % 4
	var pos = Vector2.ZERO
	match edge:
		0:  pos = Vector2(randf_range(-ARENA_HALF_W + SPAWN_MARGIN, ARENA_HALF_W - SPAWN_MARGIN), -ARENA_HALF_H + SPAWN_MARGIN)
		1:  pos = Vector2(randf_range(-ARENA_HALF_W + SPAWN_MARGIN, ARENA_HALF_W - SPAWN_MARGIN), ARENA_HALF_H - SPAWN_MARGIN)
		2:  pos = Vector2(-ARENA_HALF_W + SPAWN_MARGIN, randf_range(-ARENA_HALF_H + SPAWN_MARGIN, ARENA_HALF_H - SPAWN_MARGIN))
		3:  pos = Vector2(ARENA_HALF_W - SPAWN_MARGIN, randf_range(-ARENA_HALF_H + SPAWN_MARGIN, ARENA_HALF_H - SPAWN_MARGIN))
	return ARENA_CENTER + pos

func _on_enemy_died():
	enemies_alive = max(0, enemies_alive - 1)
	
	# Wave is complete when no enemies left alive AND spawn queue is empty
	if enemies_alive <= 0 and spawn_queue.size() == 0 and wave_in_progress:
		wave_in_progress = false
		emit_signal("wave_complete", current_wave)
		between_wave_timer = BETWEEN_WAVE_DELAY
		call_deferred("_spawn_weapon_pickup")

func _spawn_weapon_pickup():
	if GameState.is_game_over:
		return
	var weapons = ["blunderbuss", "sword", "boomerang", "wand", "trident", "drake_flask", "ghost_chain"]
	var chosen = weapons[randi() % weapons.size()]
	
	var pickup = Node2D.new()
	pickup.add_to_group("weapon_pickup_node")
	
	var vis = ColorRect.new()
	vis.size = Vector2(24, 24)
	vis.position = Vector2(-12, -12)
	match chosen:
		"blunderbuss": vis.color = Color(0.9, 0.7, 0.2)
		"sword":       vis.color = Color(0.8, 0.1, 0.1)
		"boomerang":   vis.color = Color(0.2, 0.9, 1.0)
		"wand":        vis.color = Color(0.7, 0.2, 1.0)
		"trident":     vis.color = Color(0.2, 0.8, 1.0)
		"drake_flask": vis.color = Color(1.0, 0.4, 0.1)
		"ghost_chain": vis.color = Color(0.4, 1.0, 0.5)
	pickup.add_child(vis)
	
	var lbl = Label.new()
	lbl.position = Vector2(-30, -42)
	lbl.text = "[E] " + chosen.capitalize()
	lbl.add_theme_font_size_override("font_size", 12)
	lbl.add_theme_color_override("font_color", Color(1.0, 0.9, 0.3))
	pickup.add_child(lbl)
	
	var area = Area2D.new()
	area.add_to_group("weapon_pickup")
	var col = CollisionShape2D.new()
	var shape = CircleShape2D.new()
	shape.radius = 28.0
	col.shape = shape
	area.add_child(col)
	area.collision_layer = 16
	area.collision_mask = 1
	pickup.add_child(area)
	
	pickup.global_position = ARENA_CENTER + Vector2(randf_range(-200, 200), randf_range(-100, 100))
	pickup.set_meta("weapon_type", chosen)
	pickup.set_script(load("res://scripts/WeaponPickup.gd"))
	get_tree().current_scene.add_child(pickup)
