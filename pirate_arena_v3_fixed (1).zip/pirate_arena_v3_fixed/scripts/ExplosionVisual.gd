extends Node2D

var timer: float = 0.45
var radius: float = 160.0

func _process(delta):
	timer -= delta
	if timer <= 0:
		queue_free()
		return
	queue_redraw()

func _draw():
	var alpha = timer / 0.45
	var current_r = radius * (1.0 - alpha * 0.3)
	draw_circle(Vector2.ZERO, current_r, Color(0.6, 0.2, 1.0, alpha * 0.4))
	draw_arc(Vector2.ZERO, current_r, 0, TAU, 32, Color(1.0, 0.5, 1.0, alpha), 3.0)
