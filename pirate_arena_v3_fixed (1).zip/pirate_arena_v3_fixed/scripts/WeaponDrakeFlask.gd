extends WeaponBase

# ─── SEA DRAKE FLASK ──────────────────────────────────────────────────────────
const HP_REDUCTION = 25.0

func _ready():
	weapon_name = "Sea Drake Flask"
	curse_text = "VOLATILE: Max HP reduced by 25 — liquid fire is unstable!"
	damage = 15.0
	attack_cooldown = 2.2
	super._ready()
	_apply_hp_debuff()

func _apply_hp_debuff():
	await get_tree().process_frame
	if owner_player:
		owner_player.max_health -= HP_REDUCTION
		if owner_player.health > owner_player.max_health:
			owner_player.health = owner_player.max_health
		owner_player.emit_signal("health_changed", owner_player.health, owner_player.max_health)

func _notification(what):
	if what == NOTIFICATION_PREDELETE:
		if is_instance_valid(owner_player):
			owner_player.max_health += HP_REDUCTION
			owner_player.emit_signal("health_changed", owner_player.health, owner_player.max_health)

func _do_attack():
	if owner_player == null:
		return
	var target_pos = get_global_mouse_position()
	_throw_flask(target_pos)
	get_tree().call_group("camera", "shake", 5.0, 0.12)
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("cannon_shot")

func _apply_curse():
	pass

func _throw_flask(target: Vector2):
	var flask = load("res://scripts/DrakeFlask.gd").new()
	flask.damage_val = damage
	flask.global_position = global_position
	
	var vis = ColorRect.new()
	vis.size = Vector2(20, 20)
	vis.position = Vector2(-10, -10)
	vis.color = Color(1.0, 0.45, 0.1, 0.9)
	vis.mouse_filter = Control.MOUSE_FILTER_IGNORE
	flask.add_child(vis)
	
	get_tree().current_scene.add_child(flask)
	flask.call_deferred("setup", global_position, target)
