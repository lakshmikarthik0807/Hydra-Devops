extends Camera2D

# ─── CAMERA: FOLLOWS PLAYER + SCREEN SHAKE ───────────────────────────────────
var shake_intensity: float = 0.0
var shake_duration: float = 0.0
var shake_elapsed: float = 0.0
var base_offset: Vector2 = Vector2.ZERO

# Camera follow settings
var target_node: Node2D = null
const FOLLOW_SPEED: float = 8.0   # Smooth follow lerp speed
const LOOK_AHEAD: float = 60.0    # Look slightly ahead of movement direction

# Map bounds for camera clamping (2400x1600 map centered at 1200,800)
const MAP_LEFT:   float = 40.0
const MAP_RIGHT:  float = 2360.0
const MAP_TOP:    float = 40.0
const MAP_BOTTOM: float = 1560.0

func _ready():
	add_to_group("camera")
	# Use process_mode to run even during physics
	enabled = true

func _process(delta):
	_follow_player(delta)
	_handle_shake(delta)

func _follow_player(delta):
	if target_node == null or not is_instance_valid(target_node):
		# Try to find the player
		var players = get_tree().get_nodes_in_group("player")
		if players.size() > 0:
			target_node = players[0]
		else:
			return
	
	var target_pos = target_node.global_position
	
	# Slight look-ahead based on velocity
	if target_node.has_method("get"):
		var vel = target_node.velocity
		if vel.length() > 10:
			target_pos += vel.normalized() * LOOK_AHEAD
	
	# Clamp camera to map bounds (account for half viewport)
	var half_w = get_viewport_rect().size.x / 2.0
	var half_h = get_viewport_rect().size.y / 2.0
	target_pos.x = clamp(target_pos.x, MAP_LEFT + half_w, MAP_RIGHT - half_w)
	target_pos.y = clamp(target_pos.y, MAP_TOP + half_h, MAP_BOTTOM - half_h)
	
	# Smooth follow
	global_position = global_position.lerp(target_pos, FOLLOW_SPEED * delta)

func shake(intensity: float, duration: float):
	shake_intensity = max(shake_intensity, intensity)
	shake_duration = max(shake_duration, duration)
	shake_elapsed = 0.0

func _handle_shake(delta):
	if shake_duration > 0:
		shake_elapsed += delta
		var progress = shake_elapsed / shake_duration
		
		if progress >= 1.0:
			shake_duration = 0.0
			shake_intensity = 0.0
			offset = base_offset
		else:
			var current_intensity = shake_intensity * (1.0 - progress) * (1.0 - progress)
			offset = base_offset + Vector2(
				randf_range(-current_intensity, current_intensity),
				randf_range(-current_intensity, current_intensity)
			)
