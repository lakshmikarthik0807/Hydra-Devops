extends Node2D

var bob_t: float = 0.0
var weapon_type_key: String = ""

func _ready():
	weapon_type_key = get_meta("weapon_type", "blunderbuss")
	var area_node = get_child(2)
	area_node.body_entered.connect(_on_body)

func _process(delta):
	bob_t += delta * 2.5
	position.y += sin(bob_t) * 0.35

func get_weapon_instance() -> Node2D:
	var w = Node2D.new()
	var script_path = ""
	match weapon_type_key:
		"blunderbuss": script_path = "res://scripts/WeaponBlunderbuss.gd"
		"sword":       script_path = "res://scripts/WeaponSword.gd"
		"boomerang":   script_path = "res://scripts/WeaponBoomerang.gd"
		"wand":        script_path = "res://scripts/WeaponWand.gd"
		"trident":     script_path = "res://scripts/WeaponTrident.gd"
		"drake_flask": script_path = "res://scripts/WeaponDrakeFlask.gd"
		"ghost_chain": script_path = "res://scripts/WeaponGhostChain.gd"
		_:             script_path = "res://scripts/WeaponBlunderbuss.gd"
	var s = load(script_path)
	if s:
		w.set_script(s)
	return w

func _on_body(body):
	if body.is_in_group("player"):
		body.equip_weapon(get_weapon_instance())
		queue_free()
