extends EnemyBase

# ─── SPEEDER PIRATE (Red Hat) ─────────────────────────────────────────────────
var zigzag_time: float = 0.0
var zigzag_freq: float = 3.5
var zigzag_amplitude: float = 55.0

func _ready():
	base_health = 18.0
	base_speed = 185.0
	base_damage = 8.0
	score_value = 15
	super._ready()

func _get_enemy_texture() -> Texture2D:
	var tex_path = "res://assets/textures/enemy_speeder.png"
	if ResourceLoader.exists(tex_path):
		return load(tex_path)
	return null

func _move_toward_player(delta):
	if player == null or not is_instance_valid(player):
		return
	
	zigzag_time += delta
	var to_player = player.global_position - global_position
	var dir = to_player.normalized()
	
	var perp = dir.rotated(PI / 2.0)
	var zigzag_offset = perp * sin(zigzag_time * zigzag_freq) * zigzag_amplitude
	
	velocity = (dir * speed) + zigzag_offset * delta * 3.0
