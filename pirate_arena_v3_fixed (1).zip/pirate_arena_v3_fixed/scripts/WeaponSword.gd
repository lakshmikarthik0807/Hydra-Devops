extends WeaponBase

# ─── VAMPIRIC CUTLASS ─────────────────────────────────────────────────────────
const SLASH_RANGE = 90.0
const SLASH_ARC = 120.0
const SELF_DRAIN = 3.0

var slash_visual: Node2D = null
var slash_visual_timer: float = 0.0

func _ready():
	weapon_name = "Vampiric Cutlass"
	curse_text = "BLOODCOST: Each swing drains 3 of your own HP!"
	damage = 28.0
	attack_cooldown = 0.28
	super._ready()

func _process(delta):
	super._process(delta)
	if slash_visual_timer > 0:
		slash_visual_timer -= delta
		if slash_visual != null:
			slash_visual.modulate.a = slash_visual_timer / 0.15
		if slash_visual_timer <= 0 and slash_visual != null:
			slash_visual.queue_free()
			slash_visual = null

func _do_attack():
	var enemies_hit = hit_enemies_in_range(SLASH_RANGE, SLASH_ARC)
	for enemy in enemies_hit:
		if enemy.has_method("take_damage"):
			var knock_dir = (enemy.global_position - global_position).normalized()
			enemy.take_damage(damage, knock_dir, 220.0)
	
	_spawn_slash_visual()
	get_tree().call_group("camera", "shake", 4.0, 0.08)
	
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("sword_slash")

func _apply_curse():
	if owner_player == null:
		return
	if owner_player.health > SELF_DRAIN + 1:
		owner_player.health -= SELF_DRAIN
		owner_player.emit_signal("health_changed", owner_player.health, owner_player.max_health)

func _spawn_slash_visual():
	if slash_visual != null:
		slash_visual.queue_free()
	slash_visual = Node2D.new()
	var line = Line2D.new()
	line.width = 6.0
	line.default_color = Color(0.8, 0.1, 0.1, 0.9)
	var radius = SLASH_RANGE
	var arc_rad = deg_to_rad(SLASH_ARC)
	var start_angle = rotation - arc_rad / 2.0
	for i in range(12):
		var a = start_angle + arc_rad * (i / 11.0)
		line.add_point(Vector2(cos(a), sin(a)) * radius)
	slash_visual.add_child(line)
	slash_visual.global_position = global_position
	get_tree().current_scene.add_child(slash_visual)
	slash_visual_timer = 0.15
