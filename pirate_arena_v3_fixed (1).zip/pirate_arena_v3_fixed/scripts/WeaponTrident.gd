extends WeaponBase

# ─── NEPTUNE'S TRIDENT ────────────────────────────────────────────────────────
const SLOW_AMOUNT = 0.40

func _ready():
	weapon_name = "Neptune's Trident"
	curse_text = "SEA DRAG: Movement slowed 40% — the ocean claims its toll!"
	damage = 45.0
	attack_cooldown = 1.0
	knockback_force = 300.0
	super._ready()
	_apply_speed_debuff()

func _apply_speed_debuff():
	await get_tree().process_frame
	if owner_player:
		owner_player.move_speed = owner_player.move_speed * (1.0 - SLOW_AMOUNT)

func _notification(what):
	if what == NOTIFICATION_PREDELETE:
		if is_instance_valid(owner_player):
			owner_player.move_speed = owner_player.move_speed / (1.0 - SLOW_AMOUNT)

func _do_attack():
	if owner_player == null:
		return
	var shoot_dir = (get_global_mouse_position() - global_position).normalized()
	for angle_offset in [-15.0, 0.0, 15.0]:
		var prong_dir = shoot_dir.rotated(deg_to_rad(angle_offset))
		_spawn_lance(prong_dir)
	get_tree().call_group("camera", "shake", 7.0, 0.15)
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("cannon_shot")

func _apply_curse():
	pass

func _spawn_lance(direction: Vector2):
	var b = Area2D.new()
	b.add_to_group("player_bullet")
	b.collision_layer = 4
	b.collision_mask = 2
	b.monitoring = true
	b.monitorable = false
	
	var col = CollisionShape2D.new()
	var shape = CapsuleShape2D.new()
	shape.radius = 4.0
	shape.height = 22.0
	col.shape = shape
	col.rotation = direction.angle()
	b.add_child(col)
	
	var vis = ColorRect.new()
	vis.size = Vector2(24, 8)
	vis.position = Vector2(-12, -4)
	vis.color = Color(0.2, 0.7, 1.0, 0.95)
	vis.rotation = direction.angle()
	vis.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(vis)
	
	b.global_position = global_position
	b.set_script(load("res://scripts/BulletLance.gd"))
	b.damage_val = damage
	b.velocity = direction * 780.0
	get_tree().current_scene.add_child(b)
