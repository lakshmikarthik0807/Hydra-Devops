extends Area2D

var lifetime: float = 0.65
var damage_val: float = 35.0
var velocity: Vector2 = Vector2.ZERO
var hit_enemies: Array = []

func _ready():
	body_entered.connect(_on_body)

func _process(delta):
	global_position += velocity * delta
	lifetime -= delta
	if lifetime <= 0:
		queue_free()

func _on_body(body):
	if body.is_in_group("enemy") and body not in hit_enemies:
		hit_enemies.append(body)
		if body.has_method("take_damage"):
			body.take_damage(damage_val)
		queue_free()
