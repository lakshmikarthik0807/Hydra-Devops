extends Node2D

var start_pos: Vector2
var target_pos: Vector2
var t: float = 0.0
var travel_time: float = 0.55
var exploded: bool = false
var damage_val: float = 15.0

func setup(sp: Vector2, tp: Vector2):
	start_pos = sp
	target_pos = tp

func _process(delta):
	if exploded:
		return
	t += delta / travel_time
	if t >= 1.0:
		t = 1.0
		exploded = true
		_explode()
		return
	var pos = start_pos.lerp(target_pos, t)
	pos.y -= sin(t * PI) * 90.0
	global_position = pos
	rotation += delta * 6.0

func _explode():
	var puddle = load("res://scripts/FirePuddle.gd").new()
	puddle.damage_per_tick = damage_val
	puddle.global_position = global_position
	get_tree().current_scene.add_child(puddle)
	queue_free()
