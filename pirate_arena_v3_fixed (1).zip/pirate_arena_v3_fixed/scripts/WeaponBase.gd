extends Node2D
class_name WeaponBase

# ─── WEAPON IDENTITY ──────────────────────────────────────────────────────────
@export var weapon_name: String = "Fists"
@export var curse_text: String = "No curse... yet."
@export var damage: float = 20.0
@export var attack_cooldown: float = 0.5
@export var knockback_force: float = 200.0

var cooldown_timer: float = 0.0
var owner_player: CharacterBody2D = null

func _ready():
	# Find the player via groups
	await get_tree().process_frame
	var players = get_tree().get_nodes_in_group("player")
	if players.size() > 0:
		owner_player = players[0]

func _process(delta):
	if cooldown_timer > 0:
		cooldown_timer -= delta

func attack():
	if cooldown_timer > 0:
		return
	cooldown_timer = attack_cooldown
	_do_attack()
	_apply_curse()

func _do_attack():
	pass # override in subclasses

func _apply_curse():
	pass # override in subclasses

func can_attack() -> bool:
	return cooldown_timer <= 0.0

# ─── HELPER: Hit enemies in an arc ────────────────────────────────────────────
func hit_enemies_in_range(range_px: float, arc_degrees: float = 360.0) -> Array:
	var hit = []
	var enemies = get_tree().get_nodes_in_group("enemy")
	for e in enemies:
		if not is_instance_valid(e):
			continue
		var dist = global_position.distance_to(e.global_position)
		if dist <= range_px:
			# Arc check
			if arc_degrees < 360.0:
				var to_enemy = (e.global_position - global_position).normalized()
				var facing = Vector2.RIGHT.rotated(global_rotation)
				var angle_diff = rad_to_deg(acos(clamp(to_enemy.dot(facing), -1.0, 1.0)))
				if angle_diff <= arc_degrees / 2.0:
					hit.append(e)
			else:
				hit.append(e)
	return hit

# ─── HELPER: Spawn a projectile ───────────────────────────────────────────────
func spawn_projectile(scene_path: String, direction: Vector2, speed: float, dmg: float):
	var proj_scene = load(scene_path)
	if proj_scene == null:
		return
	var proj = proj_scene.instantiate()
	proj.global_position = global_position
	proj.direction = direction
	proj.speed = speed
	proj.damage = dmg
	proj.source = "player"
	get_tree().current_scene.add_child(proj)
