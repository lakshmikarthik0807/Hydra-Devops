extends Node

# ─── PIRATE SOUND MANAGER ─────────────────────────────────────────────────────
var audio_players: Dictionary = {}
var sound_paths: Dictionary = {
	"cannon_shot": "res://assets/sounds/cannon_shot.wav",
	"sword_slash": "res://assets/sounds/sword_slash.wav",
	"enemy_hit": "res://assets/sounds/enemy_hit.wav",
	"player_hurt": "res://assets/sounds/player_hurt.wav",
	"wave_fanfare": "res://assets/sounds/wave_fanfare.wav",
	"enemy_death": "res://assets/sounds/enemy_death.wav",
	"pickup": "res://assets/sounds/pickup.wav",
	"regen_tick": "res://assets/sounds/regen_tick.wav",
}

var ambient_player: AudioStreamPlayer

func _ready():
	add_to_group("sound_manager")
	
	# Pre-create audio players
	for key in sound_paths:
		var player = AudioStreamPlayer.new()
		player.name = "SFX_" + key
		if key in ["enemy_hit", "enemy_death"]:
			player.max_polyphony = 6
		else:
			player.max_polyphony = 2
		add_child(player)
		audio_players[key] = player
		
		var path = sound_paths[key]
		if ResourceLoader.exists(path):
			player.stream = load(path)
	
	# Ambient loop
	ambient_player = AudioStreamPlayer.new()
	ambient_player.name = "Ambient"
	add_child(ambient_player)
	var ambient_path = "res://assets/sounds/ambient_loop.wav"
	if ResourceLoader.exists(ambient_path):
		var stream = load(ambient_path) as AudioStream
		if stream:
			ambient_player.stream = stream
			ambient_player.volume_db = -18.0
			ambient_player.play()

func play_sound(sound_name: String, volume_db: float = 0.0):
	if not audio_players.has(sound_name):
		return
	var player = audio_players[sound_name]
	if player and player.stream:
		player.volume_db = volume_db
		player.play()
