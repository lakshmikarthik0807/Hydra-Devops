extends CharacterBody2D

# ─── PIRATE CAPTAIN - PLAYER ─────────────────────────────────────────────────
@export var max_health: float = 100.0
@export var base_move_speed: float = 220.0
@export var move_speed: float = 220.0
@export var knockback_recovery: float = 8.0
@export var regen_rate: float = 2.0
@export var regen_delay: float = 4.0

var health: float
var current_weapon: Node = null
var is_dead: bool = false
var knockback_velocity: Vector2 = Vector2.ZERO
var invincibility_timer: float = 0.0
const INVINCIBILITY_DURATION: float = 0.3

var flash_timer: float = 0.0
const FLASH_DURATION: float = 0.15

var regen_timer: float = 0.0
var regen_tick_timer: float = 0.0

# Sprite
var sprite: Sprite2D

# ─── SIGNALS ──────────────────────────────────────────────────────────────────
signal health_changed(new_health: float, max_health: float)
signal player_died()
signal weapon_changed(weapon_name: String, curse_text: String)

@onready var weapon_holder: Node2D = $WeaponHolder
@onready var pickup_area: Area2D = $PickupArea
@onready var hurtbox: Area2D = $Hurtbox

func _ready():
	health = max_health
	sprite = $Sprite2D
	hurtbox.area_entered.connect(_on_hurtbox_entered)
	pickup_area.area_entered.connect(_on_pickup_area_entered)
	emit_signal("health_changed", health, max_health)

func _physics_process(delta):
	if is_dead:
		return
	
	_handle_invincibility(delta)
	_handle_flash(delta)
	_handle_movement(delta)
	_handle_attack()
	_handle_regen(delta)
	_clamp_to_arena()
	
	if knockback_velocity.length() > 5:
		velocity = knockback_velocity
		knockback_velocity = knockback_velocity.lerp(Vector2.ZERO, knockback_recovery * delta)
	
	move_and_slide()
	
	# Rotate weapon holder toward mouse
	var mouse_pos = get_global_mouse_position()
	var angle = (mouse_pos - global_position).angle()
	weapon_holder.rotation = angle
	
	# Flip sprite based on mouse direction
	if sprite:
		sprite.flip_h = mouse_pos.x < global_position.x

func _handle_invincibility(delta):
	if invincibility_timer > 0:
		invincibility_timer -= delta

func _handle_flash(delta):
	if flash_timer > 0:
		flash_timer -= delta
		if sprite:
			sprite.modulate = Color(1.0, 0.3, 0.3) if fmod(flash_timer * 20, 2) > 1 else Color(1.0, 1.0, 1.0)
	else:
		if sprite:
			sprite.modulate = Color(1.0, 1.0, 1.0)

func _handle_movement(delta):
	# Check for stun (Ghost Chain curse)
	if has_meta("stunned"):
		velocity = Vector2.ZERO
		return
	
	var direction = Vector2.ZERO
	# move_speed can be negative (Confusion Wand curse reverses controls)
	if Input.is_action_pressed("move_up"):    direction.y -= 1
	if Input.is_action_pressed("move_down"):  direction.y += 1
	if Input.is_action_pressed("move_left"):  direction.x -= 1
	if Input.is_action_pressed("move_right"): direction.x += 1
	
	if direction != Vector2.ZERO:
		direction = direction.normalized()
	
	velocity = direction * move_speed

func _handle_attack():
	if Input.is_action_just_pressed("attack") and current_weapon != null:
		current_weapon.attack()

func _handle_regen(delta):
	if regen_timer > 0:
		regen_timer -= delta
		return
	
	if health < max_health:
		regen_tick_timer += delta
		if regen_tick_timer >= 0.5:
			regen_tick_timer = 0.0
			var regen_amount = regen_rate * 0.5
			health = min(health + regen_amount, max_health)
			emit_signal("health_changed", health, max_health)
			var sound_bus = get_tree().get_nodes_in_group("sound_manager")
			if sound_bus.size() > 0:
				sound_bus[0].play_sound("regen_tick")

func _clamp_to_arena():
	# Updated for larger 2400x1600 map, centered at 1200,800
	var arena_half_w = 1160.0
	var arena_half_h = 760.0
	var center = Vector2(1200, 800)
	global_position.x = clamp(global_position.x, center.x - arena_half_w + 20, center.x + arena_half_w - 20)
	global_position.y = clamp(global_position.y, center.y - arena_half_h + 20, center.y + arena_half_h - 20)

func take_damage(amount: float, knockback_dir: Vector2 = Vector2.ZERO, knockback_force: float = 0.0):
	if is_dead or invincibility_timer > 0:
		return
	
	health -= amount
	flash_timer = FLASH_DURATION
	invincibility_timer = INVINCIBILITY_DURATION
	regen_timer = regen_delay
	
	if knockback_force > 0:
		knockback_velocity = knockback_dir.normalized() * knockback_force
	
	emit_signal("health_changed", health, max_health)
	get_tree().call_group("camera", "shake", 6.0, 0.15)
	
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("player_hurt")
	
	if health <= 0:
		die()

func die():
	is_dead = true
	GameState.is_game_over = true
	if sprite:
		sprite.modulate = Color(0.5, 0.1, 0.1)
	emit_signal("player_died")
	get_tree().call_group("camera", "shake", 20.0, 0.5)

func heal(amount: float):
	health = min(health + amount, max_health)
	emit_signal("health_changed", health, max_health)

func equip_weapon(weapon: Node):
	if current_weapon != null:
		current_weapon.queue_free()
	
	current_weapon = weapon
	weapon_holder.add_child(weapon)
	weapon.position = Vector2(30, 0)
	emit_signal("weapon_changed", weapon.weapon_name, weapon.curse_text)
	
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("pickup")

func _on_pickup_area_entered(area: Area2D):
	if area.is_in_group("weapon_pickup"):
		var pickup_node = area.get_parent()
		if pickup_node.has_method("get_weapon_instance"):
			equip_weapon(pickup_node.get_weapon_instance())
			pickup_node.queue_free()

func _on_hurtbox_entered(area: Area2D):
	if area.is_in_group("enemy_hitbox"):
		var enemy = area.get_parent()
		if enemy.has_method("get_damage"):
			take_damage(enemy.get_damage(), 
				(global_position - enemy.global_position).normalized(), 
				180.0)
