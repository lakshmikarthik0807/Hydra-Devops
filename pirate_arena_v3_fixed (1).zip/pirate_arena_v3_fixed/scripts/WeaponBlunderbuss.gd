extends WeaponBase

# ─── BLUNDERBUSS (PIRATE CANNON) ──────────────────────────────────────────────
func _ready():
	weapon_name = "Blunderbuss"
	curse_text = "RECOIL: Launches you backwards like a cannonball!"
	damage = 35.0
	attack_cooldown = 1.2
	knockback_force = 600.0
	super._ready()

func _do_attack():
	if owner_player == null:
		return
	
	var shoot_dir = (get_global_mouse_position() - global_position).normalized()
	var num_pellets = 7
	var spread_angle = 30.0
	
	for i in range(num_pellets):
		var angle_offset = randf_range(-spread_angle / 2.0, spread_angle / 2.0)
		var pellet_dir = shoot_dir.rotated(deg_to_rad(angle_offset))
		_spawn_pellet(pellet_dir)
	
	get_tree().call_group("camera", "shake", 14.0, 0.2)
	
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("cannon_shot")

func _apply_curse():
	if owner_player == null:
		return
	var recoil_dir = -(get_global_mouse_position() - owner_player.global_position).normalized()
	owner_player.knockback_velocity = recoil_dir * knockback_force

func _spawn_pellet(direction: Vector2):
	var b = Area2D.new()
	b.add_to_group("player_bullet")
	b.collision_layer = 4
	b.collision_mask = 2
	b.monitoring = true
	b.monitorable = false
	
	var col = CollisionShape2D.new()
	var shape = CircleShape2D.new()
	shape.radius = 5.0
	col.shape = shape
	b.add_child(col)
	
	var vis = ColorRect.new()
	vis.size = Vector2(10, 10)
	vis.position = Vector2(-5, -5)
	vis.color = Color(1.0, 0.85, 0.2)
	vis.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(vis)
	
	b.global_position = global_position
	b.set_script(load("res://scripts/BulletPellet.gd"))
	b.damage_val = damage
	b.velocity = direction * 700.0
	get_tree().current_scene.add_child(b)
