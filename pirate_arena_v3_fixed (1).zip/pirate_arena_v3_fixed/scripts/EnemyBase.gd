extends CharacterBody2D
class_name EnemyBase

# ─── PIRATE ENEMY BASE ────────────────────────────────────────────────────────
@export var base_health: float = 30.0
@export var base_speed: float = 90.0
@export var base_damage: float = 10.0
@export var score_value: int = 10
@export var contact_knockback: float = 120.0

var health: float
var max_health_scaled: float
var speed: float
var damage: float
var wave_number: int = 1
var player: CharacterBody2D = null
var is_dead: bool = false
var knockback_vel: Vector2 = Vector2.ZERO

var sprite: Sprite2D
var health_bar: ColorRect
var health_bar_bg: ColorRect

signal enemy_died()

func _ready():
	add_to_group("enemy")
	_build_visuals()
	_build_hitbox()
	
	var players = get_tree().get_nodes_in_group("player")
	if players.size() > 0:
		player = players[0]
	
	var scale_factor = 1.0 + (wave_number - 1) * 0.18
	health = base_health * scale_factor
	max_health_scaled = health
	speed = base_speed * (1.0 + (wave_number - 1) * 0.12)
	damage = base_damage * (1.0 + (wave_number - 1) * 0.1)

func _build_visuals():
	sprite = Sprite2D.new()
	var tex = _get_enemy_texture()
	if tex:
		sprite.texture = tex
		sprite.scale = Vector2(0.55, 0.55)
	sprite.position = Vector2(0, -4)
	add_child(sprite)
	
	# Health bar background
	health_bar_bg = ColorRect.new()
	health_bar_bg.size = Vector2(32, 5)
	health_bar_bg.position = Vector2(-16, -28)
	health_bar_bg.color = Color(0.15, 0.05, 0.05)
	add_child(health_bar_bg)
	
	# Health bar fill
	health_bar = ColorRect.new()
	health_bar.size = Vector2(32, 5)
	health_bar.position = Vector2(-16, -28)
	health_bar.color = Color(0.85, 0.15, 0.1)
	add_child(health_bar)

func _get_enemy_texture() -> Texture2D:
	var tex_path = "res://assets/textures/enemy_grunt.png"
	if ResourceLoader.exists(tex_path):
		return load(tex_path)
	return null

func _build_hitbox():
	var hitbox_area = Area2D.new()
	hitbox_area.add_to_group("enemy_hitbox")
	hitbox_area.collision_layer = 2
	hitbox_area.collision_mask = 0
	
	var col = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = Vector2(28, 28)
	col.shape = shape
	hitbox_area.add_child(col)
	add_child(hitbox_area)
	
	var own_col = CollisionShape2D.new()
	var own_shape = RectangleShape2D.new()
	own_shape.size = Vector2(28, 28)
	own_col.shape = own_shape
	add_child(own_col)
	collision_layer = 2
	collision_mask = 1

func _physics_process(delta):
	if is_dead:
		return
	
	if knockback_vel.length() > 5:
		velocity = knockback_vel
		knockback_vel = knockback_vel.lerp(Vector2.ZERO, 10.0 * delta)
	else:
		_move_toward_player(delta)
	
	move_and_slide()
	_update_health_bar()
	
	# Face movement direction
	if sprite and velocity.length() > 10:
		sprite.flip_h = velocity.x < 0

func _move_toward_player(delta):
	if player == null or not is_instance_valid(player):
		return
	var dir = (player.global_position - global_position).normalized()
	velocity = dir * speed

func _update_health_bar():
	if health_bar != null and max_health_scaled > 0:
		var hp_scale = health / max_health_scaled
		health_bar.size.x = 32.0 * clamp(hp_scale, 0.0, 1.0)

func take_damage(amount: float, knockback_dir: Vector2 = Vector2.ZERO, knock_force: float = 0.0):
	if is_dead:
		return
	health -= amount
	
	if knock_force > 0:
		knockback_vel = knockback_dir * knock_force
	
	# Flash white
	if sprite:
		sprite.modulate = Color(2.0, 2.0, 2.0)
		var t = get_tree().create_timer(0.08)
		t.timeout.connect(func():
			if is_instance_valid(self) and not is_dead:
				sprite.modulate = Color(1.0, 1.0, 1.0)
		)
	
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("enemy_hit")
	
	if health <= 0:
		die()

func apply_knockback(impulse: Vector2):
	knockback_vel = impulse

func die():
	if is_dead:
		return
	is_dead = true
	collision_layer = 0
	collision_mask = 0
	
	var sound_bus = get_tree().get_nodes_in_group("sound_manager")
	if sound_bus.size() > 0:
		sound_bus[0].play_sound("enemy_death")
	
	GameState.kill_enemy()
	emit_signal("enemy_died")
	
	# Death animation
	var tween = create_tween()
	tween.tween_property(self, "scale", Vector2(0.1, 0.1), 0.25)
	tween.tween_callback(queue_free)

func get_damage() -> float:
	return damage
