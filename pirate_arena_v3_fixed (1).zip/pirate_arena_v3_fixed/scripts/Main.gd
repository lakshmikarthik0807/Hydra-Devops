extends Node2D

# ─── PIRATE ARENA - MAIN (minimal: scene nodes live in Main.tscn) ─────────────

func _ready():
	GameState.reset()
	_build_arena()
	_spawn_starting_weapon()

# ─── ARENA (procedural visuals only - no characters/HUD/camera built here) ─────
func _build_arena():
	var arena = $Arena

	# Ocean background
	var bg = load("res://scripts/OceanBackground.gd").new()
	arena.add_child(bg)

	# Wooden deck floor
	var floor_node = load("res://scripts/FloorVisual.gd").new()
	arena.add_child(floor_node)

	# Physics walls
	_add_wall(arena, Vector2(40, 20),   Vector2(2320, 24))   # top
	_add_wall(arena, Vector2(40, 1556), Vector2(2320, 24))   # bottom
	_add_wall(arena, Vector2(16, 44),   Vector2(24, 1512))   # left
	_add_wall(arena, Vector2(2360, 44), Vector2(24, 1512))   # right

	# Border visuals
	_add_border_visual(arena, Vector2(40, 20),   Vector2(2320, 26), Color(0.35, 0.22, 0.09))
	_add_border_visual(arena, Vector2(40, 22),   Vector2(2320, 4),  Color(0.5, 0.35, 0.15))
	_add_border_visual(arena, Vector2(40, 1554), Vector2(2320, 26), Color(0.35, 0.22, 0.09))
	_add_border_visual(arena, Vector2(40, 1554), Vector2(2320, 4),  Color(0.5, 0.35, 0.15))
	_add_border_visual(arena, Vector2(16, 44),   Vector2(26, 1512), Color(0.35, 0.22, 0.09))
	_add_border_visual(arena, Vector2(38, 44),   Vector2(4, 1512),  Color(0.5, 0.35, 0.15))
	_add_border_visual(arena, Vector2(2358, 44), Vector2(26, 1512), Color(0.35, 0.22, 0.09))
	_add_border_visual(arena, Vector2(2358, 44), Vector2(4, 1512),  Color(0.5, 0.35, 0.15))

	# Barrels
	for bp in [
		Vector2(100, 100), Vector2(2300, 100), Vector2(100, 1500), Vector2(2300, 1500),
		Vector2(1200, 100), Vector2(1200, 1500), Vector2(100, 800), Vector2(2300, 800),
		Vector2(400, 300), Vector2(800, 300), Vector2(1600, 300), Vector2(2000, 300),
		Vector2(400, 700), Vector2(800, 700), Vector2(1600, 700), Vector2(2000, 700),
		Vector2(400, 1100), Vector2(800, 1100), Vector2(1600, 1100), Vector2(2000, 1100),
		Vector2(400, 1300), Vector2(800, 1300), Vector2(1600, 1300), Vector2(2000, 1300),
		Vector2(1050, 700), Vector2(1350, 700), Vector2(1050, 900), Vector2(1350, 900),
	]:
		_add_barrel(arena, bp)

	# Skull flags at corners
	for fp in [Vector2(100, 60), Vector2(2270, 60), Vector2(100, 1520), Vector2(2270, 1520)]:
		var flag = ColorRect.new()
		flag.size = Vector2(20, 24)
		flag.position = fp
		flag.color = Color(0.1, 0.05, 0.02)
		flag.mouse_filter = Control.MOUSE_FILTER_IGNORE
		arena.add_child(flag)

func _add_wall(parent: Node, pos: Vector2, size: Vector2):
	var wall = StaticBody2D.new()
	wall.collision_layer = 1
	wall.collision_mask = 0
	var col = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = size
	col.shape = shape
	col.position = pos + size / 2.0
	wall.add_child(col)
	parent.add_child(wall)

func _add_border_visual(parent: Node, pos: Vector2, size: Vector2, color: Color):
	var r = ColorRect.new()
	r.position = pos
	r.size = size
	r.color = color
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(r)

func _add_barrel(parent: Node, pos: Vector2):
	var body = ColorRect.new()
	body.size = Vector2(22, 26)
	body.position = pos - Vector2(11, 13)
	body.color = Color(0.38, 0.2, 0.07)
	body.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(body)
	for band_y in [pos.y - 5, pos.y + 5]:
		var band = ColorRect.new()
		band.size = Vector2(22, 3)
		band.position = Vector2(pos.x - 11, band_y)
		band.color = Color(0.55, 0.4, 0.12)
		band.mouse_filter = Control.MOUSE_FILTER_IGNORE
		parent.add_child(band)

# ─── STARTING WEAPON ──────────────────────────────────────────────────────────
func _spawn_starting_weapon():
	await get_tree().process_frame
	var players = get_tree().get_nodes_in_group("player")
	if players.size() == 0:
		return
	var weapon = Node2D.new()
	weapon.set_script(load("res://scripts/WeaponBlunderbuss.gd"))
	players[0].equip_weapon(weapon)
